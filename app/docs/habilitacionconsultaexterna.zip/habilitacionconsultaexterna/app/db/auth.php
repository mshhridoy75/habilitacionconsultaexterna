<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

function OpenCon() {
    $dbhost = getenv('DB_HOST') ?? "localhost"; 
    $dbuser = getenv('DB_USER') ?? "root";
    $dbpass = getenv('DB_PASS') ?? "";
    $dbname = getenv('DB_NAME') ?? "expertocalidad"; 

    // Crear conexión
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

    // Verificar conexión
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error); // Mensaje genérico
    }
    
    return $conn;
}

try {
    // Establecer conexión
    $conn = OpenCon();

    // Validar entradas
    $usuario = mysqli_real_escape_string($conn, $_POST['usuario']);
    $password = $_POST['password'];

    // Preparar y ejecutar la consulta para obtener el password
    $stmt = $conn->prepare("SELECT password, rol FROM usuario WHERE id = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($hashPassword, $rol);
    $stmt->fetch();

    // Verificar credenciales
    if ($stmt->num_rows > 0 && password_verify($password, $hashPassword)) {
        $_SESSION['usuario'] = $usuario;

        // Redirigir según el rol
        if ($rol === 'administrador') {
            header("Location: ../../principalAdmin.php?usuario=" . urlencode($usuario));
            exit();
        } elseif ($rol === 'odontologo') {
            header("Location: ../../sedeOdontologo.php?usuario=" . urlencode($usuario));
            exit();
        } else {
            showError("Rol desconocido.");
        }
    } else {
        showError("Credenciales incorrectas.");
    }

    // Cerrar conexiones
    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    // Manejo de excepciones
    showError($e->getMessage());
}

// Función para mostrar mensaje de error
function showError($message) {
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>habilitacionconsultaexterna</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="../../app/css/index.css" type="text/css">
    </head>
    <body class="fondo-dos">
        <div class="succ text-center">
            <div class="col-12">
                <h5>' . htmlspecialchars($message) . '</h5>
            </div>
            <div class="logo-image-big bt">
                <img src="../img/cancel.png" alt="error" class="img-succ">
            </div>
            <div>
                <a class="btn btn-danger col col-md-auto" href="../../index.php">Continuar</a>
            </div>
        </div>
    </body>
    </html>';
}
?>