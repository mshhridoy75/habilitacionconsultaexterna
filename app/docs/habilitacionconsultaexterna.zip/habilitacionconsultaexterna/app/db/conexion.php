function OpenCon() {
    $dbhost = getenv('DB_HOST') ?: "localhost";
    $dbuser = getenv('DB_USER') ?: "root";
    $dbpass = getenv('DB_PASS') ?: "";
    $db = getenv('DB_NAME') ?: "expertocalidad"; // Corregido

    try {
        $conn = new mysqli($dbhost, $dbuser, $dbpass, $db);
        if ($conn->connect_error) {
            throw new Exception("Connection failed"); // Mensaje genérico
        }
    } catch (Exception $e) {
        error_log("Database connection error: " . $e->getMessage()); // Log privado
        die("Database connection error."); // Mensaje sin detalles específicos
    }

    echo "Conexión establecida...";
    return $conn;
}
